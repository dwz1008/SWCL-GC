import torch
import networkx as nx
from torch_geometric.datasets import Planetoid
from torch_geometric.utils import to_undirected, add_remaining_self_loops
from torch_sparse import SparseTensor

def pre_data_cora():
    # 假设 args.dataset = 'Cora'
    args = type('', (), {})()  # 创建一个空的对象，模拟 args
    args.dataset = 'Cora'
    args.verbose = True
    # 设置路径和加载数据集
    path = 'data/'
    if args.dataset in ['Cora', 'Citeseer']:
        dataset = Planetoid(path, args.dataset)  # 加载 Planetoid 数据集（如 Cora, Citeseer）
    else:
        raise RuntimeError(f"Unknown dataset {args.dataset}")
    # 数据预处理
    data = dataset[0]  # 获取第一个图数据对象
    x, edge_index, y = data.x, data.edge_index, data.y
    N, E = data.num_nodes, data.num_edges
    # 确保图是无环的并增加自环
    edge_index = to_undirected(add_remaining_self_loops(edge_index)[0])
    # 构建 NetworkX 图对象
    G = nx.Graph()  # 创建一个无向图对象
    # 添加节点到图中
    for i in range(N):
        G.add_node(i, feature=x[i].numpy())  # 将每个节点及其特征添加到图中
    # 添加边到图中
    edge_list = edge_index.t().cpu().numpy()  # 转置并转为 NumPy 数组
    for edge in edge_list:
        G.add_edge(edge[0],edge[1],weight = 1)
    print(G)
    return G


pre_data_cora()
