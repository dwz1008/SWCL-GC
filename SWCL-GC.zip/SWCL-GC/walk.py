# import random
# import networkx as nx
# import itertools
# from pre_data import pre_data_cora
# import torch
# def weighted_choice(neighbors, weights):
#     """
#     根据权重大小选择节点，权重越大被选择的概率越高。
#
#     :param neighbors: list，候选节点列表
#     :param weights: list，对应的权重列表（非负）
#     :return: 选择的节点
#     """
#     cumulative_weights = list(itertools.accumulate(weights))  # 计算累积权重
#     rand_val = random.uniform(0, cumulative_weights[-1])  # 在 [0, 总权重] 内随机取值
#
#     # 找到第一个累积权重大于等于 rand_val 的索引
#     for i, cw in enumerate(cumulative_weights):
#         if rand_val < cw:
#             return neighbors[i]
#
#
# class CustomWalker:
#     def __init__(self, G, walk_length=3,num_walks=20):
#         # 初始化图、游走参数以及其他配置
#         self.G = G
#         self.walk_length = walk_length  # 每次游走的步数
#         self.num_walks = num_walks  # 每个节点执行的游走次数
#         # self.p = p  # 返回参数
#         # self.q = q  # 入/出参数
#         # self.workers = workers  # 使用的线程数
#

    # def custom_walk(self, walk_length, start_nodes):
    #     """
    #     自定义的随机游走方式，每次游走从起始节点开始，到达一个节点后，
    #     删除该节点并将该节点的邻居连接到起始节点，并调整边的权重。
    #
    #     :param walk_length: 游走的步长
    #     :param start_nodes: 一个包含多个起始节点的列表或张量
    #     :return: 返回形状为 (len(start_nodes), walk_length-1) 的二维张量，每行表示一次游走路径（去掉起始节点）
    #     """
    #     walks = []
    #
    #     for start_node in start_nodes:
    #         walk = [start_node]  # 初始化游走路径，起始节点
    #
    #         while len(walk) < walk_length:
    #             G = self.G.copy()
    #             cur = walk[0]  # 当前节点
    #
    #             neighbors = list(G.neighbors(cur))  # 获取当前节点的所有邻居
    #
    #             if len(neighbors) > 0:  # 如果当前节点有邻居
    #                 # 随机选择一个邻居作为下一个节点
    #                 # print(1)
    #                 weights = [G[cur][nbr]['weight'] for nbr in neighbors]
    #                 next_node = random.choices(neighbors, weights=weights, k=1)[0]
    #
    #                 # 将被删除节点的所有邻居连接到起始节点
    #                 for nbr in list(G.neighbors(next_node)):
    #                     if G.has_edge(start_node, nbr):  # 如果起始节点与邻居已连接，增加边权重
    #                         prev_weight = G[next_node][start_node]['weight']
    #                         G[start_node][nbr]['weight'] += prev_weight
    #                     else:  # 如果起始节点与邻居未连接，新增边并设定权重为 1
    #                         prev_weight = G[next_node][start_node]['weight'] / 2
    #                         G.add_edge(start_node, nbr, weight=prev_weight)  # 这里可以根据需要调整初始权重
    #
    #                 # 删除当前节点
    #                 G.remove_node(cur)
    #                 # 将选择的下一个节点添加到游走路径中
    #                 walk.append(next_node)
    #             else:
    #                 break  # 如果没有邻居，则停止游走
    #         walks.append(walk[1:])  # 只保留游走路径，不包括起始节点
    #     # 将多次游走的结果合并成一个二维列表
    #     # 转换为二维格式（len(start_nodes), walk_length-1）
    #     max_walks = max(len(w) for w in walks)
    #     padded_walks = [w + [None] * (max_walks - len(w)) for w in walks]  # 填充为相同长度
    #     # 将最终的游走路径转换为Tensor，并返回
    #     return padded_walks

#     # du
#
#
#
#
#
#     def simulate_walks(self):
#         """
#         从图中的每个节点开始，模拟多次随机游走。
#         """
#         walks = []
#         nodes = list(self.G.nodes())  # 获取所有节点
#
#         for _ in range(self.num_walks):  # 执行 num_walks 次游走
#             random.shuffle(nodes)  # 打乱节点顺序
#             for v in nodes:  # 对每个节点进行游走
#                 walks.append(self.custom_walk(self.walk_length, [v]))  # 将游走结果加入到 walks 列表
#         return walks
#
#
# # 使用示例
# # # 创建一个图（这里只是为了演示，实际使用时会有不同的图）
# # G = pre_data_cora()
# #
# #
# # walker = CustomWalker(G, walk_length=5, num_walks=3)  # 创建游走对象
# # walks = walker.simulate_walks()  # 执行游走
#
# # 打印生成的游走路径
# # for walk in walks:
# #     print(walk)


from tqdm import tqdm

import numpy as np
import networkx as nx
import scipy.sparse as sp
import matplotlib.pyplot as plt
from sklearn.preprocessing import normalize
from gensim.models import Word2Vec
import random
import itertools



class CustomWalker:
    def __init__(self, adj_matrix, num_nodes, num_walks=10, walk_length=10):
        self.adj_matrix = adj_matrix
        self.num_nodes = num_nodes
        self.num_walks = num_walks
        self.walk_length = walk_length
        if isinstance(adj_matrix, np.ndarray):
            adj_matrix = sp.csr_matrix(adj_matrix)

            # **手动构造 NetworkX 图**
        self.G = nx.Graph()
        coo = adj_matrix.tocoo()  # 转换为 COOrdinate 格式，方便遍历

        # **添加边，并设置权重为 1.0**
        for i, j, v in zip(coo.row, coo.col, coo.data):
            if i != j:
                self.G.add_edge(i, j, weight=1.0)  # 统一权重为 1.0

    def weighted_choice(self, neighbors, weights):
        """根据权重大小选择节点，权重越大被选择的概率越高"""
        cumulative_weights = list(itertools.accumulate(weights))
        rand_val = random.uniform(0, cumulative_weights[-1])
        for i, cw in enumerate(cumulative_weights):
            if rand_val < cw:
                return neighbors[i]

    def custom_walk(self,t):
        t = t
        """执行自定义的随机游走"""
        walks = []
        # 用于记录修改的边及其原始权重。
        modified_edges = {}
        # 记录已经被访问过的节点
        visited_nodes = set()

        for _ in tqdm(range(self.num_walks), desc="Random Walk Progress"):
            print(len(walks))
            # for start_node in tqdm(range(self.num_nodes), desc=" Num_nodes Progress"):
            #     walk = [start_node]
            #
            #     # print(start_node)
            #     G = self.G.copy()
            #     # G = nx.Graph(self.G)
            #
            #     while len(walk) < self.walk_length:
            #
            #
            #
            #         cur = walk[0]  # 取当前游走的最后一个节点
            #         # # print(cur)
            #         if cur not in G:
            #             break;
            #
            #
            #         neighbors = list(G.neighbors(cur))# 获取邻居节点
            #         # print(neighbors)
            #
            #         if len(neighbors) == 0:
            #             break  # 没有邻居，停止游走
            #
            #         # 获取边的权重并加权随机选择下一个节点
            #         weights = [G[cur][nbr].get('weight') for nbr in neighbors]
            #         next_node = random.choices(neighbors, weights=weights, k=1)[0]
            #         # print(next_node)
            #         # 重新连接被删除节点的邻居到起始节点
            #         for nbr in list(G.neighbors(next_node)):
            #             if G.has_edge(start_node, nbr):  # 如果起始节点与邻居已连接，增加边权重
            #
            #                 prev_weight = G[next_node][start_node]['weight']
            #                 G[start_node][nbr]['weight'] += prev_weight
            #
            #             elif not G.has_edge(cur, nbr):  # 如果起始节点与邻居未连接，新增边并设定权重为 1
            #
            #                 prev_weight = G[next_node][cur]['weight'] / 2
            #                 G.add_edge(start_node, nbr, weight=prev_weight)  # 这里可以根据需要调整初始权重
            #
            #         # 删除当前节点并继续
            #         walk.append(next_node)
            #         # print(next_node)
            #         G.remove_node(next_node)
            #
            #
            #     walks.append(walk)  # 只保留去掉起始节点后的游走路径
            for start_node in tqdm(range(self.num_nodes), desc="Num_nodes Progress"):

                walk = [start_node]

                cur = walk[0]
                if cur not in self.G:
                    walks.append(walk)
                    continue;

                available_nodes = {}
                for nbr in self.G.neighbors(start_node):
                    available_nodes[nbr] = self.G[start_node][nbr].get('weight', 1.0)


                while len(walk) < self.walk_length:

                    if cur not in self.G:
                        break;

                    if not available_nodes:
                        break  # No more nodes to select

                    # Convert available nodes to lists for random.choices
                    nodes, weights = zip(*available_nodes.items())

                    # Weighted random selection
                    selected_node = random.choices(nodes, weights=weights, k=1)[0]
                    walk.append(selected_node)

                    selected_node_weight = available_nodes[selected_node]
                    # Remove selected node from available nodes
                    del available_nodes[selected_node]

                    # Add selected node's neighbors (excluding start_node) with half weight
                    for nbr in self.G.neighbors(selected_node):
                        if nbr != start_node and nbr not in walk:
                            if nbr in available_nodes:
                                available_nodes[nbr] += selected_node_weight / t
                            else:
                                available_nodes[nbr] = selected_node_weight / t

                walks.append(walk)

        return walks







