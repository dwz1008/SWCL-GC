import numpy as np
import networkx as nx
import scipy.sparse as sp
import matplotlib.pyplot as plt
from sklearn.preprocessing import normalize
from gensim.models import Word2Vec
from walk import CustomWalker
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score as ari_score
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi_score
import os
from torch_geometric.datasets import Planetoid , Amazon

lujing =  'pHTO_walks_100_5.npy'
dataset =  'Photo'
temp_num_walks= 100
temp_walk_deep= 5

# from node2vec import Node2Vec
def plot_clusters(embeddings, labels):
    """使用 PCA 进行降维并可视化聚类结果"""
    pca = PCA(n_components=3)
    reduced_embeddings = pca.fit_transform(embeddings)
    plt.scatter(reduced_embeddings[:, 0], reduced_embeddings[:, 1], c=labels, cmap='viridis', alpha=0.7)
    plt.colorbar()
    plt.title("K-Means Clustering of Node Embeddings")
    plt.show()

def load_cora_adj_matrix(dataset):
    """加载 Cora 数据集的邻接矩阵"""
    dataset = Amazon(root='data/'+ dataset, name=dataset)
    edge_index = dataset[0].edge_index.numpy()

    # 构建邻接矩阵
    num_nodes = dataset[0].x.shape[0]
    adj_matrix = sp.coo_matrix((np.ones(edge_index.shape[1]), (edge_index[0], edge_index[1])),
                               shape=(num_nodes, num_nodes), dtype=np.float32)
    G = nx.Graph()
    for node in range(num_nodes):
        G.add_node(node)
    for i in range(edge_index.shape[1]):
        G.add_edge(int(edge_index[0, i]), int(edge_index[1, i]))
    # 归一化邻接矩阵
    adj_matrix = adj_matrix + sp.eye(num_nodes)  # 添加自环
    deg_matrix = np.array(adj_matrix.sum(axis=1)).flatten()
    deg_inv_sqrt = np.power(deg_matrix, -0.5)
    deg_inv_sqrt[np.isinf(deg_inv_sqrt)] = 0.0
    d_mat_inv_sqrt = sp.diags(deg_inv_sqrt)
    adj_matrix = d_mat_inv_sqrt @ adj_matrix @ d_mat_inv_sqrt
    return adj_matrix.todense(), num_nodes, dataset[0].y.numpy(),G








# def train_node2vec(walks, embedding_dim=64, window_size=5, workers=4, epochs=10):
#     """使用 Word2Vec 训练节点嵌入"""
#     model = Word2Vec(sentences=walks, vector_size=embedding_dim, window=window_size, workers=workers, epochs=epochs)
#
#     return model
import numpy as np
from gensim.models import Word2Vec # 自然语言处理
def save_walks_to_npy(walks, file_path="citeseer_walks_1.npy"):
    """将游走路径存储到 NumPy 二进制文件"""
    np.save(file_path, np.array(walks, dtype=object))



# 加载 Cora 邻接矩阵
adj_matrix, num_nodes ,true_labels , G = load_cora_adj_matrix(dataset)

if os.path.exists(lujing):
    walks=np.load(lujing, allow_pickle=True).tolist()
    walks = [[str(node) for node in walk] for walk in walks]
    print(walks[:5])
else:
    for t in [40,50]:
        custom_walk_obj = CustomWalker(adj_matrix, num_nodes, num_walks=temp_num_walks, walk_length=temp_walk_deep)
        walks = custom_walk_obj.custom_walk(t)
        walks = [[str(node) for node in walk] for walk in walks]
        save_walks_to_npy(walks, f'Photo_walks_100_4_{t}.npy')
        print(walks)
        # walks = walks.tolist()
        # walks = [[str(node) for node in walk] for walk in walks]



print(walks)