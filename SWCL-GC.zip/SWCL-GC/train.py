import os
# os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
import csv
import random
import argparse
import networkx as nx
import numpy as np
import torch
# torch.cuda.empty_cache()
import os
# os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
# 提供激活函数、损失函数
import torch.nn.functional as F
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
# 图卷积层的实现
from torch_geometric.nn import GCNConv
from torch_sparse import SparseTensor
from torch_geometric.datasets import Planetoid, Amazon
# 将有向图转为无向图，增加自环 有利于图卷积捕获节点自身的信息
from torch_geometric.utils import to_undirected, add_remaining_self_loops
from Cortra_Learn_walk.utils import setup_seed,get_sim,scale,get_mask,clustering
from Cortra_Learn_walk.Loss import Loss
from model import Encoder,Model
from matplotlib.colors import ListedColormap
from torch_geometric.data import Data
import scipy.sparse as sp
parser = argparse.ArgumentParser()
parser.add_argument('--verbose', type=bool, default=True, help='')
parser.add_argument('--runs', type=int, default= 10 , help='runs')
parser.add_argument('--t', type=int, default= 10 , help='runs')
# dataset para
parser.add_argument('--dataset', type=str, default='Cora')

# model para
parser.add_argument('--hidden', type=str, default='512', help='GNN encoder')
parser.add_argument('--projection', type=str, default='', help='Projection')

# sample para
parser.add_argument('--wt', type=int, default=100,
                    help='number of random walks')
parser.add_argument('--wl', type=int, default=3, help='depth of random walks')
parser.add_argument('--tau', type=float, default=0.3, help='temperature')

# learning para
parser.add_argument('--dropout', type=float, default=0.1, help='')
parser.add_argument('--lr', type=float, default=0.0005, help='learning rate')
parser.add_argument('--wd', type=float, default=1e-3, help='weight decay')
parser.add_argument('--epochs', type=int, default=400)
parser.add_argument('--ns', type=float, default=0.5, help='')
args = parser.parse_args()
def run(runs=10, result=None):
    if result and not os.path.exists(result):
        with open(result, 'w', encoding='utf-8-sig', newline='') as f_w:
            writer = csv.writer(f_w)
            # 写入参数信息
            if args is not None:
                writer.writerow(['Parameters'])
                for key, value in vars(args).items():
                    writer.writerow([key, value])
                writer.writerow([])  # 空行分隔

            writer.writerow(
                ['runs', 'acc', 'nmi', 'ari', 'f1_macro', 'f1_micro'])
    ACC, NMI, ARI, F1_MA, F1_MI = [], [], [], [], []
    for i in range(runs):
        print(f'\n----------------------runs {i+1: d} start')
        acc, nmi, ari, f1_macro, f1_micro = train()
        print(f'\n----------------------runs {i+1: d} over')
        if result:
            with open(result, 'a', encoding='utf-8', newline='') as f_w:
                writer = csv.writer(f_w)
                writer.writerow([i+1, acc, nmi, ari, f1_macro, f1_micro])
        ACC.append(acc)
        NMI.append(nmi)
        ARI.append(ari)
        F1_MA.append(f1_macro)
        F1_MI.append(f1_micro)
    ACC = np.array(ACC)
    NMI = np.array(NMI)
    ARI = np.array(ARI)
    F1_MA = np.array(F1_MA)
    F1_MI = np.array(F1_MI)

    print(f'mean | ACC={ACC.mean():.4f}, NMI={NMI.mean():.4f},  ARI={ARI.mean():.4f}, '
          f'f1_macro={F1_MA.mean():.4f}, f1_micro={F1_MI.mean():.4f}')
    print(f'std | ACC={ACC.std():.4f}, NMI={NMI.std():.4f},  ARI={ARI.std():.4f}, '
          f'f1_macro={F1_MA.std():.4f}, f1_micro={F1_MI.std():.4f}')

    if result:
        with open(result, 'a', encoding='utf-8-sig', newline='') as f_w:
            writer = csv.writer(f_w)
            writer.writerow(['mean', ACC.mean(), NMI.mean(),
                            ARI.mean(), F1_MA.mean(), F1_MI.mean()])
            writer.writerow(['std', ACC.std(), NMI.std(),
                            ARI.std(), F1_MA.std(), F1_MI.std()])


def train():
    lu = f'Cora_walks_100_4_{args.t}.npy'
    #设置随机种子
    randint = random.randint(1,1000000)
    setup_seed(randint)
    if args.verbose:
        print('random seed : ', randint,'\n', args)

    device = torch.device('cuda' if torch.cuda.is_available() else "cpu")
    print(torch.cuda.is_available())

    path = 'data/'+args.dataset
    if args.dataset in ['Cora', 'Citeseer']:
        dataset = Planetoid(path, args.dataset)
    elif args.dataset in ['Photo', 'Computers']:
        dataset = Amazon(path, args.dataset)
    else:
        raise RuntimeError(f"Unknown dataset {args.dataset}")

    data = dataset[0]

    #du ==================================================
    # adj = np.load('data/eat/eat_adj.npy')  # shape: (num_nodes, num_nodes)
    # feat = np.load('data/eat/eat_feat.npy')  # shape: (num_nodes, num_features)
    # label = np.load('data/eat/eat_label.npy')  # shape: (num_nodes,)

    # # 如果 adj 是稀疏矩阵的 dense 形式，先转换为 COO 格式
    # if not sp.issparse(adj):
    #     adj = sp.coo_matrix(adj)
    #
    # # 转换为 edge_index
    # edge_index = torch.tensor(np.vstack((adj.row, adj.col)), dtype=torch.long)
    #
    # # 转换特征和标签
    # x = torch.tensor(feat, dtype=torch.float)
    # y = torch.tensor(label, dtype=torch.long)
    #
    # # 构建 PyTorch Geometric 的 Data 对象
    # data = Data(x=x, edge_index=edge_index, y=y)




    #====================================================
    # edge_index 代表 tensor([[ 633, 1862, 2582,  ...,  598, 1473, 2706],
    #  [   0,    0,    0,  ..., 2707, 2707, 2707]])    上面一个与下面的一对一的对应边
    x, edge_index, y = data.x, data.edge_index, data.y


    N, E = data.num_nodes, data.num_edges
    # 增加自环边
    edge_index = to_undirected(add_remaining_self_loops(edge_index)[0])
    # adj 等于 （1.2，1） 节点 1 和节点2 之间右边， 三元组的形式进行存储
    adj = SparseTensor(row=edge_index[0],
                       col=edge_index[1], sparse_sizes=(N, N))
    # 非0元素设置为1
    adj.fill_value_(1.)
    # du
    # 根据 边 创建一个 G 图，关于Cora数据集
    #-------------------------------------------------------
    G = nx.Graph()  # 创建一个无向图对象
    # 添加节点到图中
    for i in range(N):
        G.add_node(i, feature=x[i].numpy())  # 将每个节点及其特征添加到图中
    # 添加边到图中
    edge_list = edge_index.t().cpu().numpy()  # 转置并转为 NumPy 数组
    for edge in edge_list:
        G.add_edge(edge[0], edge[1], weight=1)
    adj.G = G
    #--------------------------------------------------------
    # 创建一个长度为 N的张量 1~N
    batch = torch.LongTensor(list(range(N)))
    # 得到一个子图 通过saint的方式

    batch, adj_batch = get_sim(batch, adj, wt=args.wt, wl=args.wl,lujing=lu)




    # 保留下出现频率高的节点。
    mask = get_mask(adj_batch , x)
    print(mask)

    # 隐藏层的维度
    hidden = list(map(int, args.hidden.split(',')))

    if args.projection == '':
        projection = None
    else:
        projection = list(map(int, args.projection.split(',')))


    # 创建encoder  使用GCNConv层来进行表征
    encoder = Encoder(data.num_features, hidden, base_model=GCNConv,
                      dropout=args.dropout, ns=args.ns).to(device)
    #
    model = Model(
        encoder, in_channels=hidden[-1], project_hidden=projection, tau=args.tau).to(device)
    x, edge_index = data.x.to(device), data.edge_index.to(device)
    optimizer = torch.optim.Adam(
        model.parameters(), lr=args.lr, weight_decay=args.wd)
    dataset2n_clusters = {'Cora': 7,
                          'Citeseer': 6, 'Photo': 8, 'Computers': 10,'eat':4,'bat':4}
    n_clusters = dataset2n_clusters[args.dataset]
    # train
    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad()
        out = model(x, edge_index)
        # 归一化进行处理
        out = scale(out)
        out = F.normalize(out, p=2, dim=1)
        loss = model.loss(out, mask)
        loss.backward()
        optimizer.step()
        if args.verbose:
            print(f'(T) | Epoch={epoch:03d}, loss={float(loss):.4f}')

    # eval
    with torch.no_grad():
        model.eval()
        out = model(x, edge_index)
        out = scale(out)
        out = F.normalize(out, p=2, dim=1).detach().cpu()
        acc, nmi, ari, f1_macro, f1_micro = clustering(
            out.numpy(), n_clusters, y.numpy(), spectral_clustering = True)

    print(
        f'train over | ACC={acc:.4f}, NMI={nmi:.4f},  ARI={ari:.4f}, f1_macro={f1_macro:.4f}, f1_micro={f1_micro:.4f}')

    # du T-SNE ============================================
    tsne = TSNE(n_components=2, perplexity=100, max_iter=1000, random_state=42)
    embeddings_2d = tsne.fit_transform(out.numpy())

    plt.figure(figsize=(8, 6))
    cmap = ListedColormap(['r', 'g', 'b', 'y', 'c', 'm', 'orange', 'purple'])
    np.savez(
        f'tsne_result_ours_{args.dataset}_wt_{args.wt}.npz',
        original_embeddings=out.numpy(),
        tsne_embeddings=embeddings_2d,
        labels=y.numpy()
    )
    scatter = plt.scatter(embeddings_2d[:, 0], embeddings_2d[:, 1], c=y.numpy(), cmap=cmap, s=10)
    plt.title(f't-SNE Visualization (dataset={args.dataset}, wl={args.wl})')
    plt.colorbar(scatter)
    plt.tight_layout()
    plt.savefig(f'tsne_{args.dataset}_wl{args.t}_{args.runs}.png', dpi=300)
    # plt.savefig(f'tsne_Cora_wl{args.wl}.png', dpi=300)
    plt.close()
    # du T-SNE ============================================
    return acc, nmi, ari, f1_macro, f1_micro



if __name__ == '__main__':
    result_dir = 'results_t_scan_Cora'
  #  result_dir = 'results_wl_scan_Node2Vec_Photo'
    os.makedirs(result_dir, exist_ok=True)


    t_values = [40]
    for t in t_values:
        print(f'\n\n========= Running for wl = {t} =========')
        args.t = t  # 动态设置tau
        result_file = os.path.join(result_dir, f'result_t_{t}.csv')
        run(args.runs, result_file)

    # result = 'result.csv'
    # run(args.runs, result)