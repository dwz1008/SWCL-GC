import torch
import torch.nn as nn
import torch.nn.functional as F

class Loss(nn.Module):
    def __init__(self, temperature=0.07, scale_by_temperature=True, scale_by_weight=False):
        super(Loss, self).__init__()
        self.temperature = temperature
        self.scale_by_temperature = scale_by_temperature
        self.scale_by_weight = scale_by_weight

    def forward(self, out, mask):
        device = out.device

        # 从mask中获取正样本对的索引和权重
        row, col, val = mask.storage.row(), mask.storage.col(), mask.storage.value()
        row, col = row.to(device), col.to(device)
        batch_size = out.shape[0]

        # 计算相似度矩阵
        similarity = torch.matmul(out, out.T)  # [batch_size, batch_size]
        similarity = similarity / self.temperature

        # 数值稳定性：减去每行的最大值
        similarity_max, _ = torch.max(similarity, dim=1, keepdim=True)
        similarity = similarity - similarity_max.detach()

        # 创建掩码排除自身对比
        logits_mask = torch.ones_like(similarity, device=device)
        logits_mask.fill_diagonal_(0)

        # 计算指数相似度（排除自身）
        exp_sim = torch.exp(similarity) * logits_mask

        # 获取正样本对的权重
        if self.scale_by_weight:
            weights = val.to(device)
        else:
            weights = torch.ones(len(row), device=device)

        # 计算每个样本的正样本指数和（加权）
        pos_exp = exp_sim[row, col] * weights
        sum_pos_exp = torch.zeros(batch_size, device=device)
        sum_pos_exp.scatter_add_(0, row, pos_exp)  # 按行聚合

        # 计算分母：所有负样本和正样本的指数和
        sum_exp_all = exp_sim.sum(dim=1)  # [batch_size]

        # 计算对数概率（添加epsilon防止log(0)）
        log_prob = torch.log(sum_pos_exp + 1e-8) - torch.log(sum_exp_all + 1e-8)
        loss = -log_prob

        # 应用温度缩放
        if self.scale_by_temperature:
            loss = loss * self.temperature

        # 过滤无正样本的实例并计算平均损失
        valid_mask = sum_pos_exp > 0
        if valid_mask.sum() == 0:
            return torch.tensor(0.0, device=device)

        final_loss = loss[valid_mask].mean()
        return final_loss


 # # simLearning
 #    def forward(self, out, mask):
 #        """
 #            :param out: [N, D] 节点嵌入向量
 #            :param mask: 稀疏正样本矩阵 (only positive pairs), torch_sparse.SparseTensor 类型
 #        """
 #        device = out.device
 #        N = out.size(0)
 #
 #        # 单位归一化
 #        out = F.normalize(out, p=2, dim=1)
 #
 #        # 正样本对索引
 #        row, col = mask.storage.row().to(device), mask.storage.col().to(device)
 #
 #        # 计算相似度矩阵（对称）
 #        sim_matrix = torch.matmul(out, out.T)  # [N, N]
 #
 #        # 创建正样本掩码
 #        pos_mask = torch.zeros(N, N, device=device)
 #        pos_mask[row, col] = 1
 #        pos_mask[col, row] = 1  # 对称性：正样本对 (i,j) 和 (j,i)
 #
 #        # 创建负样本掩码：所有非自身、非正样本
 #        neg_mask = 1 - pos_mask - torch.eye(N, device=device)
 #
 #        # 对每个节点计算损失
 #        pos_sum = (sim_matrix * pos_mask).sum(dim=1)
 #        neg_sum = (sim_matrix * neg_mask).sum(dim=1)
 #
 #        loss = -pos_sum + neg_sum
 #
 #        # 只保留至少有一个正样本的节点
 #        valid_mask = pos_mask.sum(dim=1) > 0
 #        return loss[valid_mask].mean() if valid_mask.any() else torch.tensor(0.0, device=device)
 #



# class Loss(nn.Module):
#     def __init__(self, temperature=0.07, scale_by_temperature=True, scale_by_weight=False):
#         super(Loss, self).__init__()
#         self.temperature = temperature
#         self.scale_by_temperature = scale_by_temperature
#         self.scale_by_weight = scale_by_weight
#
#     def forward(self, out, mask):
#         device = (torch.device('cuda') if out.is_cuda else torch.device('cpu'))
#
#         row, col, val = mask.storage.row(), mask.storage.col(), mask.storage.value()
#         row, col, val = row.to(device), col.to(device), val.to(device)
#         batch_size = out.shape[0]
#
#         # compute logits
#         dot = torch.matmul(out, out.T)
#         dot = torch.div(dot, self.temperature)
#
#         # for numerical stability
#         logits_max, _ = torch.max(dot, dim=1, keepdim=True)
#         dot = dot - logits_max.detach()
#
#         logits_mask = torch.scatter(
#             torch.ones(batch_size, batch_size).to(device),
#             1,
#             torch.arange(batch_size).view(-1, 1).to(device),
#             0
#         )
#
#
#         exp_logits = torch.exp(dot) * logits_mask
#         log_probs = dot - torch.log(exp_logits.sum(1, keepdim=True))
#
#         if torch.any(torch.isnan(log_probs)):
#             raise ValueError("Log_prob has nan!")
#
#         labels = row.view(row.shape[0], 1)
#         unique_labels, labels_count = labels.unique(dim=0, return_counts=True)
#         log_probs = log_probs[row, col]
#
#         log_probs = log_probs.view(-1, 1)
#         loss = torch.zeros_like(unique_labels, dtype=torch.float).to(device)
#         loss.scatter_add_(0, labels, log_probs)
#         loss = -1 * loss / labels_count.float().unsqueeze(1)
#
#         if self.scale_by_temperature:
#             loss *= self.temperature
#         loss = loss.mean()
#         return loss