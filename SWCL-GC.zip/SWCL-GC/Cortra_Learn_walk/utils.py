import random
import torch
import numpy as np
from tqdm import tqdm
from torch_sparse import SparseTensor
from sklearn.cluster import SpectralClustering
from sklearn.cluster import KMeans
from walk import CustomWalker
# try:
#     from sklearnex import patch_sklearn
# except:
#     def patch_sklearn(): return

# from magi.clustering_metric import clustering_metrics
# from magi.batch_kmeans_cuda import kmeans
# from magi.walk import CustomWalker
import os
import math
import torch.nn.utils.rnn as rnn_utils
try:
    from sklearnex import patch_sklearn
except:
    def patch_sklearn(): return

from clustering_metric import clustering_metrics
from kmeans_gpu import kmeans

#lujing= f'Cora_walks_100_4_{args.t}.npy'


def process_walks(rw, min_len=2):
    return [
        walk[:min_len] if len(walk) >= min_len
        else walk + [walk[0]] * (min_len - len(walk))
        for walk in rw
    ]


def get_sim(batch, adj, wt=1, wl=2,lujing=2):
    lujing = lujing
    rowptr, col,_= adj.csr()
    batch_size = batch.shape[0]
    batch_repeat = batch.repeat(wt)
    #
    # du ---------------------------------------------------------
    if os.path.exists('D:\\Users\\Du\\Desktop\\test_walk\\'+lujing):
        walks = np.load('D:\\Users\\Du\\Desktop\\test_walk\\'+lujing, allow_pickle=True).tolist()
        num_keep = batch.shape[0] * wt  # 假设你只想保留 repeat 后的 batch_repeat 对应的游走次数
        walks = walks[:num_keep]
        rw = [[str(node) for node in walk] for walk in walks]
        print(walks[:5])
    else:
        custom_walk_obj = CustomWalker(adj.G,walk_length=2, num_walks=1)  # adj.G 代表图结构
        rw = custom_walk_obj.custom_walk(walk_length=wl + 1, start_nodes=batch_repeat.tolist())  # 获取游走路径

    rw = process_walks(rw, min_len = wl)

    # 将节点转换为整数类型
    rw = [[int(node) for node in walk] for walk in rw]
    max_length = max(len(row) for row in rw)  # 找到最长的子列表
    rw_padded = np.array([row + [row[0]] * (max_length - len(row)) for row in rw])  # 补 -1
    rw_tensor = torch.tensor(rw_padded, dtype=torch.long)

    rw = rw_tensor[:, 1:]
    print(rw)
    # # du==============================================================
    #
    # rw = adj.random_walk(batch_repeat, wl)[:, 1:]
    #检查rw是不是 torch，tensor类型   rw.t 为转置操作， (n,-1)
    if not isinstance(rw, torch.Tensor):
        rw = rw[0]

    rw = rw.t().reshape(-1, batch_size).t()

    row, col, val = [], [], []
    # 统计每一个节点出现的次数
    for i in range(batch.shape[0]):
        # 统计有rw中的唯一节点，每个元素出现的次数
        rw_nodes, rw_times = torch.unique(rw[i], return_counts=True)
        row += [batch[i].item()] * rw_nodes.shape[0]
        col += rw_nodes.tolist()
        val += rw_times.tolist()

    # 找到独一无二的节点，并建立一个索引0跟第一个节点 1跟第二个节点，并将其转换为字典格式
    unique_nodes = list(set(row + col))
    subg2g = dict(zip(unique_nodes, list(range(len(unique_nodes)))))

    #统一索引
    row = [subg2g[x] for x in row]
    col = [subg2g[x] for x in col]
    idx = torch.tensor([subg2g[x] for x in batch.tolist()])

    #建立稀疏矩阵
    adj_ = SparseTensor(row=torch.LongTensor(row), col=torch.LongTensor(col), value=torch.tensor(val),
                        sparse_sizes=(len(unique_nodes), len(unique_nodes)))
    # adj_batch, _ = adj_.saint_subgraph(idx)
    adj_batch = adj_
    adj_batch = adj_batch.set_diag(0.)

    # src, dst = dict_r[idx[adj_batch.storage.row()[3].item()].item()], dict_r[idx[adj_batch.storage.col()[3].item()].item()]
    return batch, adj_batch
def clustering(feature, n_clusters, true_labels, kmeans_device='cpu', batch_size=100000, tol=1e-4, device=torch.device('cuda:0'), spectral_clustering=False):
    if spectral_clustering:
        if isinstance(feature, torch.Tensor):
            feature = feature.numpy()
        print("spectral clustering on cpu...")
        patch_sklearn()
        Cluster = SpectralClustering(
            n_clusters=n_clusters, affinity='precomputed', random_state=0)
        f_adj = np.matmul(feature, np.transpose(feature))
        predict_labels = Cluster.fit_predict(f_adj)
    else:
        if kmeans_device == 'cuda':
            if isinstance(feature, np.ndarray):
                feature = torch.tensor(feature)
            print("kmeans on gpu...")
            predict_labels, _ = kmeans(
                X=feature, num_clusters=n_clusters, batch_size=batch_size, tol=tol, device=device)
            predict_labels = predict_labels.numpy()
        else:
            if isinstance(feature, torch.Tensor):
                feature = feature.numpy()
            print("kmeans on cpu...")
            patch_sklearn()
            Cluster = KMeans(n_clusters=n_clusters, max_iter=10000, n_init=20)
            predict_labels = Cluster.fit_predict(feature)

    cm = clustering_metrics(true_labels, predict_labels)
    acc, nmi, adjscore, fms, f1_macro, f1_micro = cm.evaluationClusterModelFromLabel(
        tqdm)
    return acc, nmi, adjscore, f1_macro, f1_micro

def scale(z: torch.Tensor):
    zmax = z.max(dim=1, keepdim=True)[0]
    zmin = z.min(dim=1, keepdim=True)[0]
    z_std = (z - zmin) / ((zmax - zmin) + 1e-20)
    z_scaled = z_std
    return z_scaled


# def combine_sparse_and_mask(adj_, mask_1):
#     # 将 mask_1 转换为稀疏坐标格式（非零元素的行列索引）
#     rows_mask, cols_mask = torch.where(mask_1 != 0)
#     rows_mask = rows_mask.to(adj_.device())
#     cols_mask = cols_mask.to(adj_.device())
#
#     # 提取 adj_ 的稀疏坐标
#     rows_adj = adj_.storage.row()
#     cols_adj = adj_.storage.col()
#
#     # 合并两者的行列索引
#     combined_rows = torch.cat([rows_adj, rows_mask])
#     combined_cols = torch.cat([cols_adj, cols_mask])
#
#     # 去重：合并后的坐标唯一性处理
#     combined_indices = torch.stack([combined_rows, combined_cols], dim=1)
#     unique_indices = torch.unique(combined_indices, dim=0)
#
#     # 生成新的稀疏矩阵（值全部设为 1）
#     new_rows = unique_indices[:, 0]
#     new_cols = unique_indices[:, 1]
#     new_val = torch.ones(new_rows.size(0), device=new_rows.device)
#
#     # 构造合并后的 SparseTensor
#     combined_adj = SparseTensor(
#         row=new_rows,
#         col=new_cols,
#         value=new_val,
#         sparse_sizes=adj_.sparse_sizes(),
#     )
#
#     return combined_adj

def combine_sparse_and_mask(adj_, mask_1):
    # 将 mask_1 转换为稀疏坐标格式：获取非零元素的行、列索引以及对应的值
    rows_mask, cols_mask = torch.where(mask_1 != 0)
    rows_mask = rows_mask.to(adj_.device())
    cols_mask = cols_mask.to(adj_.device())
    vals_mask = mask_1[rows_mask, cols_mask]

    # 提取 adj_ 的稀疏坐标和值
    rows_adj = adj_.storage.row()
    cols_adj = adj_.storage.col()
    vals_adj = adj_.storage.value()

    # 合并两个稀疏矩阵的坐标和值
    combined_rows = torch.cat([rows_adj, rows_mask])
    combined_cols = torch.cat([cols_adj, cols_mask])
    combined_vals = torch.cat([vals_adj, vals_mask])

    # 将合并后的坐标堆叠起来
    combined_indices = torch.stack([combined_rows, combined_cols], dim=1)
    # 对坐标进行去重，同时获取反向索引，用于后续将重复的值合并
    unique_indices, inverse_indices = torch.unique(combined_indices, dim=0, return_inverse=True)

    # 对重复出现的坐标对应的值进行合并
    # 这里采用求和的方式，如有需要可替换为其他聚合策略（比如取平均或选择其中一个值）
    combined_vals_new = torch.zeros(unique_indices.size(0), device=combined_vals.device)
    combined_vals_new = combined_vals_new.scatter_add_(0, inverse_indices, combined_vals)

    new_rows = unique_indices[:, 0]
    new_cols = unique_indices[:, 1]
    new_vals = combined_vals_new

    # 构造新的 SparseTensor
    combined_adj = SparseTensor(
        row=new_rows,
        col=new_cols,
        value=new_vals,
        sparse_sizes=adj_.sparse_sizes(),
    )

    return combined_adj

def blockwise_quantile(tensor, q=0.98, block_size=100000):
    numel = tensor.numel()
    device = tensor.device
    quantiles = []

    for start in range(0, numel, block_size):
        end = min(start + block_size, numel)
        block = tensor[start:end]
        quantiles.append(torch.quantile(block, q).item())

    # 转为 tensor 后再求一次分位数
    quantiles_tensor = torch.tensor(quantiles, device=device)
    return torch.quantile(quantiles_tensor, q)
def get_mask(adj, X):
    # 计算行之间的欧氏距离 dwz
    # ---------------------------------------------------------------------------
    dist = torch.cdist(X, X, p=2)

    # 使用高斯函数计算相似度（根据距离转换成相似度）
    sigma = 1.0  # 高斯函数的宽度，通常需要调整
    similarity = torch.exp(-dist ** 2 / (2 * sigma ** 2))
    similarity.fill_diagonal_(0)
    x_flat = similarity.flatten()

    # 计算前 20% 的值（即 80% 分位数）
    threshold = blockwise_quantile(x_flat, q=0.98)

    # 创建一个掩码，将大于等于阈值的值标记为 1，其余的设置为 0
    mask_1 = (similarity >= threshold).float()

    #----------------------------------------------------------------------


    rows = adj.storage.row()
    cols = adj.storage.col()
    vals = adj.storage.value()

    # 按行排序并获取对应的索引
    sorted_rows, sorted_indices = torch.sort(rows)
    unique_rows, counts = torch.unique_consecutive(sorted_rows, return_counts=True)
    row_ptr = torch.cat([torch.tensor([0], device=rows.device), counts.cumsum(dim=0)])

    mask = torch.zeros(rows.size(0), dtype=torch.bool, device=rows.device)

    for i in range(len(unique_rows)):
        start = row_ptr[i]
        end = row_ptr[i+1]
        group_size = end - start

        if group_size == 0:
            continue  # 跳过空行
        # dwz
        k =  math.ceil(group_size * 0.30)

        # 获取当前行的元素在原数据中的索引
        group_indices = sorted_indices[start:end]
        group_values = vals[group_indices]
        # 选择前k个最大值的索引
        if k >= group_size:
            selected_indices = group_indices
        else:
            _, topk_rel_indices = torch.topk(group_values, k, largest=True)
            selected_indices = group_indices[topk_rel_indices]

        mask[selected_indices] = True

    # 构建新的稀疏矩阵，保留的元素值设为1
    row = rows[mask]
    col = cols[mask]
    val = torch.ones(mask.sum(), device=mask.device)
    adj_ = SparseTensor(row=row, col=col, value=val, sparse_sizes=adj.sparse_sizes())



    #dwz
    # -------------------------------------------------------------------------

    adj_ = combine_sparse_and_mask(adj_, mask_1)
    # ---------------------------------------------------------------------------
    return adj_

def setup_seed(seed):
    # cpu 上运行生成的随机种子
    torch.manual_seed(seed)
    # GPU上运行的时候生成的
    torch.cuda.manual_seed_all(seed)
    # numpy的随机数生成的种子
    np.random.seed(seed)
    # 随机random中生成的
    random.seed(seed)
    # 利用nvidia GPU进行加速
    torch.backends.cudnn.deterministic = True

